FFmpeg 64-bit shared Windows build from www.gyan.dev

Version: 4.3.1-2020-10-01-full_build-www.gyan.dev

License: GPL v3

Source Code: https://github.com/FFmpeg/FFmpeg/commit/8a2acdc6da

release-full build configuration: 

    --enable-gpl
    --enable-version3
    --enable-shared
    --disable-w32threads
    --disable-autodetect
    --enable-fontconfig
    --enable-iconv
    --enable-gnutls
    --enable-libxml2
    --enable-gmp
    --enable-lzma
    --enable-libsnappy
    --enable-zlib
    --enable-libsrt
    --enable-libssh
    --enable-libzmq
    --enable-avisynth
    --enable-libbluray
    --enable-libcaca
    --enable-sdl2
    --enable-libdav1d
    --enable-libzvbi
    --enable-librav1e
    --enable-libwebp
    --enable-libx264
    --enable-libx265
    --enable-libxvid
    --enable-libaom
    --enable-libopenjpeg
    --enable-libvpx
    --enable-libass
    --enable-frei0r
    --enable-libfreetype
    --enable-libfribidi
    --enable-libvidstab
    --enable-libvmaf
    --enable-libzimg
    --enable-amf
    --enable-cuda-llvm
    --enable-cuvid
    --enable-ffnvcodec
    --enable-nvdec
    --enable-nvenc
    --enable-d3d11va
    --enable-dxva2
    --enable-libmfx
    --enable-libcdio
    --enable-libgme
    --enable-libmodplug
    --enable-libopenmpt
    --enable-libopencore-amrwb
    --enable-libmp3lame
    --enable-libshine
    --enable-libtheora
    --enable-libtwolame
    --enable-libvo-amrwbenc
    --enable-libilbc
    --enable-libgsm
    --enable-libopencore-amrnb
    --enable-libopus
    --enable-libspeex
    --enable-libvorbis
    --enable-ladspa
    --enable-libbs2b
    --enable-libflite
    --enable-libmysofa
    --enable-librubberband
    --enable-libsoxr
    --enable-chromaprint
